package com.Proyecto.Gestor_Contable.repository;

import com.Proyecto.Gestor_Contable.modelo.MovimientoFinanciero;
import org.springframework.stereotype.Repository;
import org.springframework.data.mongodb.repository.MongoRepository;

import java.time.LocalDate;
import java.time.LocalDateTime;
import java.util.List;

@Repository
public interface MovimientoRepository extends MongoRepository<MovimientoFinanciero, String> {
    List<MovimientoFinanciero> findByNegocioId(String negocioId);
    List<MovimientoFinanciero> findByNegocioIdAndFechaBetween(String negocioId, LocalDate desde, LocalDate hasta);
    List<MovimientoFinanciero> findByNegocioIdAndPeriodo_MesIgnoreCaseAndPeriodo_Anio(String negocioId, String mes, Integer anio);
}
