package com.Proyecto.Gestor_Contable.controller;

import com.Proyecto.Gestor_Contable.dtos.NegocioRequest;
import com.Proyecto.Gestor_Contable.dtos.NegocioResponse;
import com.Proyecto.Gestor_Contable.service.NegocioServicio;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;
import org.springframework.security.access.prepost.PreAuthorize;
import java.util.List;

@RestController
@RequestMapping("/api/negocio")
@CrossOrigin(origins = "*")
public class NegocioController {

    @Autowired
    private NegocioServicio negocioServicio;

    @PostMapping("/crear")
    public ResponseEntity<NegocioResponse> crear(@RequestBody NegocioRequest request){
        return ResponseEntity.status(HttpStatus.CREATED).body(negocioServicio.crear(request));
    }

    @GetMapping("/mis-negocios")
    public ResponseEntity<List<NegocioResponse>> listarMisNegocios(){
        return ResponseEntity.ok(negocioServicio.listarPorUsuarioAutenticado());
    }

    @PreAuthorize("@negocioSecurity.esDueno(#id, authentication.name)")
    @PutMapping("/{id}")
    public ResponseEntity<NegocioResponse> actualizar(@PathVariable String id, @RequestBody NegocioRequest request){
        return ResponseEntity.ok(negocioServicio.actualizar(id, request));
    }
    @PreAuthorize("@negocioSecurity.esDueno(#id, authentication.name)")
    @DeleteMapping("/{id}")
    public ResponseEntity<Void> eliminar(@PathVariable String id){
        negocioServicio.eliminar(id);
        return ResponseEntity.noContent().build();
    }

    @PreAuthorize("@negocioSecurity.esDueno(#idNegocio, authentication.name)")
    @GetMapping("/{id}/utilidad")
    public ResponseEntity<Double> calcularUtilidad(@PathVariable("id") String idNegocio){
        return ResponseEntity.ok(negocioServicio.calcularUtilidades(idNegocio));
    }

    @PreAuthorize("@negocioSecurity.esDueno(#idNegocio, authentication.name)")
    @GetMapping("/{id}/financiero")
    public ResponseEntity<Object> verResumen(@PathVariable("id") String idNegocio){
        return ResponseEntity.ok(negocioServicio.verResumenFinanciero(idNegocio));
    }
}